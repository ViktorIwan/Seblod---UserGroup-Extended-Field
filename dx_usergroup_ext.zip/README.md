User Group Seblod's Field Extended
===================


This plugin is an alternative of default Seblod's Usergroup plugin. It has extended feature such as
 1. Display the usergroup in checkbox or dropdown format
 2. Filter by specific Parent Group
 3. Option to display Parent Group itself in final output




How to Install
--------------

 1. Install Zip Files
 2. Activate the plugin in Extension



How to Use
--------------

1. Add new Field
2. Choose "User Group - Extended" under Joomla Library (JForm) Group
3. Parent User ID: Choose Parent
4. Display Type: Choose to display Dropdown or Checkbox Format
5. Include ParentID in List: Choose to display Parent Group in final output or keep it hidden